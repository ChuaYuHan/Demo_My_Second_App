package sg.edu.rp.c346.id19020844.demomysecondapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DemoMyLoginApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_my_login_app);
    }
}
